# NammaSkill - Android Studio Project

## How to open in Android Studio
1. Open Android Studio
2. Click "Open"
3. Select this folder (NammaSkill-Firebase)
4. Wait for Gradle sync to complete (5-10 mins first time)
5. Connect your phone with USB Debugging ON
6. Click the ▶ Run button

## Firebase Features
- Live seat counts (real-time Firestore)
- User registration & login (Firebase Auth)
- Application submission (saved to Firestore)
- Interest pings (saved to Firestore)

## Project: namma-skill-4d3dc
